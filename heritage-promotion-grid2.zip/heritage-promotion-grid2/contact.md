---
layout: page
title: Επικοινωνία
permalink: /contact/
image: "/heritage-promotion/assets/images/contact.png"
---

<style>
  body {
    background-color: #C0C0C0;
  }
</style>

<div style="
    max-width: 100%;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.1); 
    overflow: hidden;
">
    <img src="/heritage-promotion/assets/images/contact.png" alt="Contact" style="
        width: 100%;
        height: auto;
        display: block;
    ">
</div>

<p>Για περισσότερες πληροφορίες πατήστε <a href="https://ministryofjustice.gr/wp-content/uploads/2024/06/Efeteia_04062024.pdf" target="_blank">εδώ</a>.</p>
