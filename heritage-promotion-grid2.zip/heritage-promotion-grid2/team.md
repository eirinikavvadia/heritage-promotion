---
layout: page
title: Η ομάδα μας
permalink: /team/
---

<!-- Banner Image -->
<div style="
    width: 100%;
    height: 320px;
    background-image: url('{{ "/assets/images/nauplio.jpg" | relative_url }}'); 
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    border-radius: 15px;
    overflow: hidden;
    margin-bottom: 20px;">
</div>

<style>
  body {
    background-color: #C0C0C0;
  }
    .justified-text {
        text-align: justify;
  }
</style>

<div class="justified-text">
    <p>Η ιστοσελίδα αυτή δημιουργήθηκε από τις μεταπτυχιακές φοιτήτριες Χρυσάνθη Βασιλείου, Ειρήνη Καββαδία και Αφροδίτη Παναγιώτου, στα πλαίσια του μαθήματος Εργαλεία Προβολής Τουριστικού και Πολιτιστικού Προϊόντος του ΠΜΣ Ψηφιακές Εφαρμογές και Καινοτομία του Ιονίου Πανεπιστημίου.</p>
</div>
